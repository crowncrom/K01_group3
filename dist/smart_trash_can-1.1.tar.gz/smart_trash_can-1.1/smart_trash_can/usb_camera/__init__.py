from .usb_camera import (
    UsbCamera
)

__version__ = '0.0.0'