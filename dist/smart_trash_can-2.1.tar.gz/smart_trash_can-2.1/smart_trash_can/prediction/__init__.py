from .prediction import (
    Prediction
)

__version__ = '0.0.0'