# What's this project

K01 Group3 Development repo

# Create package

```
python setup.py sdist
```

# Install package

```
pip install dist/smart_trash_can*
```

